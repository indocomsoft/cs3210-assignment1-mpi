#include "master.h"
#include "slave.h"
#include <mpi.h>
#include <stdio.h>
