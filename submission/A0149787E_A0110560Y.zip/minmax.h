#ifndef MINMAX_DEFINED
#define MINMAX_DEFINED

#define max(a, b) (((a) >= (b)) ? (a) : (b))
#define min(a, b) (((a) <= (b)) ? (a) : (b))

#endif
